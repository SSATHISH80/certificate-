classdef Akos < handle
    properties
        card = 'Jack of Spades'
    end   
end