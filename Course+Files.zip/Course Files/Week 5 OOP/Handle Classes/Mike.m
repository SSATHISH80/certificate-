classdef Mike
    properties
        card = 'Jack of Spades'
    end   
end