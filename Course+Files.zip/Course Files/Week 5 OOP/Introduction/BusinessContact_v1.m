classdef BusinessContact < Contact
    properties
        Company
        Fax
    end
end